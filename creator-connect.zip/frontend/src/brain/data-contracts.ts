/** CookieModel */
export interface CookieModel {
  /** Name */
  name: string;
  /** Value */
  value: string;
  /** Domain */
  domain: string;
  /**
   * Path
   * @default "/"
   */
  path?: string | null;
  /** Expires */
  expires?: number | null;
  /**
   * Httponly
   * @default false
   */
  httpOnly?: boolean | null;
  /**
   * Secure
   * @default false
   */
  secure?: boolean | null;
  /** Samesite */
  sameSite?: string | null;
}

/** HTTPValidationError */
export interface HTTPValidationError {
  /** Detail */
  detail?: ValidationError[];
}

/** HealthResponse */
export interface HealthResponse {
  /** Status */
  status: string;
}

/** SaveCookiesRequest */
export interface SaveCookiesRequest {
  /** Cookies */
  cookies: CookieModel[];
}

/** ValidationError */
export interface ValidationError {
  /** Location */
  loc: (string | number)[];
  /** Message */
  msg: string;
  /** Error Type */
  type: string;
}

/** SessionStatusResponse */
export interface AppApisInitPySessionStatusResponse {
  /** Status */
  status: string;
  /** Message */
  message?: string | null;
  user?: AppApisInitPyUserDetail | null;
}

/** UserDetail */
export interface AppApisInitPyUserDetail {
  /** Username */
  username: string;
  /** Id */
  id?: string | null;
}

/** SessionStatusResponse */
export interface AppApisTiktokSessionApiSessionStatusResponse {
  /** Status */
  status: string;
  /** Message */
  message?: string | null;
  user?: AppApisTiktokSessionApiUserDetail | null;
}

/** UserDetail */
export interface AppApisTiktokSessionApiUserDetail {
  /** Username */
  username: string;
  /** Id */
  id?: string | null;
  /**
   * Source
   * @default "mock"
   */
  source?: string | null;
}

export type CheckHealthData = HealthResponse;

export type SaveTiktokCookiesEndpointData = AppApisTiktokSessionApiSessionStatusResponse;

export type SaveTiktokCookiesEndpointError = HTTPValidationError;

export type CheckTiktokSessionEndpointData = AppApisTiktokSessionApiSessionStatusResponse;

export type AttemptTiktokLoginEndpointData = AppApisTiktokSessionApiSessionStatusResponse;
