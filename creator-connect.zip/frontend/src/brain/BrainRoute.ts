import {
  AttemptTiktokLoginEndpointData,
  CheckHealthData,
  CheckTiktokSessionEndpointData,
  SaveCookiesRequest,
  SaveTiktokCookiesEndpointData,
} from "./data-contracts";

export namespace Brain {
  /**
   * @description Check health of application. Returns 200 when OK, 500 when not.
   * @name check_health
   * @summary Check Health
   * @request GET:/_healthz
   */
  export namespace check_health {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = CheckHealthData;
  }

  /**
   * No description
   * @tags TikTok Session, dbtn/module:tiktok_session_api
   * @name save_tiktok_cookies_endpoint
   * @summary Save Tiktok Cookies Endpoint
   * @request POST:/routes/api/session/save-tiktok-cookies
   */
  export namespace save_tiktok_cookies_endpoint {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = SaveCookiesRequest;
    export type RequestHeaders = {};
    export type ResponseBody = SaveTiktokCookiesEndpointData;
  }

  /**
   * No description
   * @tags TikTok Session, dbtn/module:tiktok_session_api
   * @name check_tiktok_session_endpoint
   * @summary Check Tiktok Session Endpoint
   * @request GET:/routes/api/session/check-tiktok-session
   */
  export namespace check_tiktok_session_endpoint {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = CheckTiktokSessionEndpointData;
  }

  /**
   * No description
   * @tags TikTok Session, dbtn/module:tiktok_session_api
   * @name attempt_tiktok_login_endpoint
   * @summary Attempt Tiktok Login Endpoint
   * @request POST:/routes/api/session/attempt-tiktok-login
   */
  export namespace attempt_tiktok_login_endpoint {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = AttemptTiktokLoginEndpointData;
  }
}
