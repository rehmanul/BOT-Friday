import {
  AttemptTiktokLoginEndpointData,
  CheckHealthData,
  CheckTiktokSessionEndpointData,
  SaveCookiesRequest,
  SaveTiktokCookiesEndpointData,
  SaveTiktokCookiesEndpointError,
} from "./data-contracts";
import { ContentType, HttpClient, RequestParams } from "./http-client";

export class Brain<SecurityDataType = unknown> extends HttpClient<SecurityDataType> {
  /**
   * @description Check health of application. Returns 200 when OK, 500 when not.
   *
   * @name check_health
   * @summary Check Health
   * @request GET:/_healthz
   */
  check_health = (params: RequestParams = {}) =>
    this.request<CheckHealthData, any>({
      path: `/_healthz`,
      method: "GET",
      ...params,
    });

  /**
   * No description
   *
   * @tags TikTok Session, dbtn/module:tiktok_session_api
   * @name save_tiktok_cookies_endpoint
   * @summary Save Tiktok Cookies Endpoint
   * @request POST:/routes/api/session/save-tiktok-cookies
   */
  save_tiktok_cookies_endpoint = (data: SaveCookiesRequest, params: RequestParams = {}) =>
    this.request<SaveTiktokCookiesEndpointData, SaveTiktokCookiesEndpointError>({
      path: `/routes/api/session/save-tiktok-cookies`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * No description
   *
   * @tags TikTok Session, dbtn/module:tiktok_session_api
   * @name check_tiktok_session_endpoint
   * @summary Check Tiktok Session Endpoint
   * @request GET:/routes/api/session/check-tiktok-session
   */
  check_tiktok_session_endpoint = (params: RequestParams = {}) =>
    this.request<CheckTiktokSessionEndpointData, any>({
      path: `/routes/api/session/check-tiktok-session`,
      method: "GET",
      ...params,
    });

  /**
   * No description
   *
   * @tags TikTok Session, dbtn/module:tiktok_session_api
   * @name attempt_tiktok_login_endpoint
   * @summary Attempt Tiktok Login Endpoint
   * @request POST:/routes/api/session/attempt-tiktok-login
   */
  attempt_tiktok_login_endpoint = (params: RequestParams = {}) =>
    this.request<AttemptTiktokLoginEndpointData, any>({
      path: `/routes/api/session/attempt-tiktok-login`,
      method: "POST",
      ...params,
    });
}
