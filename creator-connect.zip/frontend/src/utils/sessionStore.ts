import { create } from 'zustand';
import brain from '../brain';
import {
  SessionStatusResponse,
  UserDetail,
} from '../brain/data-contracts'; // Adjust path as needed

interface RawCookie {
  name: string;
  value: string;
  domain: string;
  path?: string | null;
  expires?: string | number | null;
  httpOnly?: string | boolean | null;
  httponly?: string | boolean | null; // Handle lowercase 'httponly' from some exports
  secure?: string | boolean | null;
  sameSite?: "Strict" | "Lax" | "None" | "" | null;
  [key: string]: any; 
}

export interface ApiCookie {
  name: string;
  value: string;
  domain: string;
  path?: string | null;
  expires?: number | null;
  httpOnly?: boolean | null;
  secure?: boolean | null;
  sameSite?: "Strict" | "Lax" | "None" | null;
}

interface TikTokUser {
  username: string;
  id?: string | null;
}

type TikTokSessionStatus = "Disconnected" | "Connecting" | "CookiesFound" | "Connected" | "Error" | "Warning" | "CookiesSaved";

interface SessionState {
  tiktokSessionStatus: TikTokSessionStatus;
  tiktokUser: TikTokUser | null;
  errorMessage: string | null;
  isLoading: boolean;
  actions: {
    checkInitialSession: () => Promise<void>;
    connectToTikTok: () => Promise<void>;
    saveCookiesAndConnect: (rawCookies: RawCookie[]) => Promise<void>;
    disconnectFromTikTok: () => Promise<void>;
  };
}

const transformRawCookiesToApiCookies = (rawCookies: RawCookie[]): ApiCookie[] => {
  return rawCookies.map(rawCookie => {
    let expiresTimestamp: number | null = null;
    if (typeof rawCookie.expires === 'string') {
      const parsedDate = Date.parse(rawCookie.expires);
      expiresTimestamp = !isNaN(parsedDate) ? parsedDate / 1000 : null;
    } else if (typeof rawCookie.expires === 'number') {
      expiresTimestamp = rawCookie.expires === -1 ? null : rawCookie.expires;
    }

    const rawHttpOnly = rawCookie.httpOnly !== undefined ? rawCookie.httpOnly : rawCookie.httponly;
    const httpOnlyBool = typeof rawHttpOnly === 'string' ? rawHttpOnly.toUpperCase() === 'TRUE' : (!!rawHttpOnly);
    const secureBool = typeof rawCookie.secure === 'string' ? rawCookie.secure.toUpperCase() === 'TRUE' : (!!rawCookie.secure);

    let sameSiteValue: ApiCookie['sameSite'] = null;
    if (rawCookie.sameSite && typeof rawCookie.sameSite === 'string') {
        const ssLower = rawCookie.sameSite.toLowerCase();
        if (ssLower === "strict" || ssLower === "lax" || ssLower === "none") {
            sameSiteValue = rawCookie.sameSite.charAt(0).toUpperCase() + ssLower.slice(1) as ApiCookie['sameSite'];
        }
    }

    const apiCookie: Partial<ApiCookie> = {
      name: rawCookie.name,
      value: rawCookie.value,
      domain: rawCookie.domain,
    };

    if (rawCookie.path) apiCookie.path = rawCookie.path;
    if (expiresTimestamp !== null) apiCookie.expires = expiresTimestamp;
    if (httpOnlyBool !== undefined) apiCookie.httpOnly = httpOnlyBool; // Send if explicitly true or false
    if (secureBool !== undefined) apiCookie.secure = secureBool; // Send if explicitly true or false
    if (sameSiteValue) apiCookie.sameSite = sameSiteValue;
    
    return apiCookie as ApiCookie;
  });
};


const useSessionStore = create<SessionState>((set, get) => ({
  tiktokSessionStatus: "Disconnected",
  tiktokUser: null,
  errorMessage: null,
  isLoading: false,
  actions: {
    checkInitialSession: async () => {
      set({ isLoading: true, tiktokSessionStatus: "Connecting", errorMessage: null });
      try {
        const response = await brain.check_tiktok_session_endpoint();
        const data = await response.json() as SessionStatusResponse;
        
        if (data.status === "CookiesFoundButNotVerified") {
          set({ tiktokSessionStatus: "CookiesFound", isLoading: false, errorMessage: data.message });
          await get().actions.connectToTikTok();
        } else if (data.status === "NoCookieFile") {
          set({ tiktokSessionStatus: "Disconnected", isLoading: false, errorMessage: data.message });
        } else if (data.status === "Connected" && data.user) {
           set({ tiktokSessionStatus: "Connected", tiktokUser: data.user as TikTokUser, isLoading: false });
        } else {
            set({ tiktokSessionStatus: "Disconnected", isLoading: false, errorMessage: data.message || "Initial session check returned unexpected status." });
        }
      } catch (error: any) {
        console.error("Error checking initial session:", error);
        const message = error.response && typeof error.response.json === 'function' ? JSON.stringify(await error.response.json()) : error.message;
        set({ tiktokSessionStatus: "Error", errorMessage: `Could not check session status: ${message}`, isLoading: false });
      }
    },
    connectToTikTok: async () => {
      set({ isLoading: true, tiktokSessionStatus: "Connecting", errorMessage: null });
      try {
        const response = await brain.attempt_tiktok_login_endpoint();
        const data = await response.json() as SessionStatusResponse;

        if (data.status === "Connected" && data.user) {
          set({ tiktokSessionStatus: "Connected", tiktokUser: data.user as TikTokUser, isLoading: false });
        } else {
          set({ tiktokSessionStatus: "Error", tiktokUser: null, errorMessage: data.message || "Failed to connect.", isLoading: false });
        }
      } catch (error: any) {
        console.error("Error connecting to TikTok:", error); 
        const message = error.response && typeof error.response.json === 'function' ? JSON.stringify(await error.response.json()) : error.message;
        set({ tiktokSessionStatus: "Error", errorMessage: `Connection attempt failed: ${message}`, isLoading: false });
      }
    },
    saveCookiesAndConnect: async (rawCookiesFromJson: RawCookie[]) => {
      set({ isLoading: true, tiktokSessionStatus: "Connecting", errorMessage: null });
      try {
        const apiCookies = transformRawCookiesToApiCookies(rawCookiesFromJson);
        const body = { cookies: apiCookies }; 
        const saveResponse = await brain.save_tiktok_cookies_endpoint(body);
        const saveData = await saveResponse.json() as SessionStatusResponse;

        if (saveData.status === "CookiesSaved") {
          set({ tiktokSessionStatus: "CookiesSaved", isLoading: false, errorMessage: saveData.message });
          await get().actions.connectToTikTok();
        } else {
            set({ tiktokSessionStatus: "Error", errorMessage: saveData.message || "Failed to save cookies (server indicated an issue).", isLoading: false });
        }
      } catch (error: any) {
        console.error("Error saving cookies and connecting:", error);
        let detailMessage = error.message;
        if (error.response && typeof error.response.json === 'function') {
            try {
                const errorData = await error.response.json();
                detailMessage = errorData.detail || JSON.stringify(errorData);
            } catch (jsonError) {
                detailMessage = "Could not parse error response from server during save.";
            }
        }
        set({ tiktokSessionStatus: "Error", errorMessage: `Save cookies failed: ${detailMessage}`, isLoading: false });
      }
    },
    disconnectFromTikTok: async () => {
      set({ isLoading: true });
      // TODO: Optionally call a backend endpoint to clear cookies from db.storage
      set({
        tiktokSessionStatus: "Disconnected",
        tiktokUser: null,
        errorMessage: null,
        isLoading: false,
      });
    },
  },
}));

export default useSessionStore;
