import React from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Zap, Search, Target, BarChart2, Settings, ShieldCheck } from "lucide-react"; // Example icons

export default function App() {
  const navigate = useNavigate();
  const features = [
    {
      icon: <Search size={32} className="text-primary" />,
      title: "Advanced Creator Discovery",
      description: "Find the perfect TikTok affiliates with powerful, granular filtering options based on follower count, product category, GMV, and more.",
    },
    {
      icon: <Zap size={32} className="text-primary" />,
      title: "Intelligent Invitation System",
      description: "Automate your outreach with smart, GMV-based invitation logic, rate limiting, and personalized collaboration proposals.",
    },
    {
      icon: <Target size={32} className="text-primary" />,
      title: "Automated Campaign Management",
      description: "Set invitation targets, monitor real-time progress, and track creator responses all from a centralized dashboard.",
    },
     {
      icon: <BarChart2 size={32} className="text-accent" />,
      title: "Reporting & Analytics",
      description: "Gain insights with detailed reports on invitation success, creator engagement, and overall campaign ROI.",
    },
    {
      icon: <Settings size={32} className="text-accent" />,
      title: "Comprehensive Configuration",
      description: "Fine-tune every aspect of your campaigns, from creator filters and GMV thresholds to daily invitation limits.",
    },
    {
      icon: <ShieldCheck size={32} className="text-accent" />,
      title: "Safe & Compliant Automation",
      description: "Operate securely with built-in rate limiting, anti-detection measures, and robust error recovery.",
    }
  ];

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-background text-foreground p-4 md:p-8">
      <header className="text-center mb-12 md:mb-16">
        <h1 className="text-5xl md:text-7xl font-bold mb-4">
          <span className="text-primary">Creator</span>
          <span className="text-accent">Connect</span>
        </h1>
        <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto">
          The ultimate TikTok Affiliate Invitation Bot. Automate your outreach, connect with top creators, and scale your brand collaborations effortlessly.
        </p>
      </header>

      <main className="container mx-auto px-4 w-full max-w-5xl">
        <section className="mb-12 md:mb-16">
          <h2 className="text-3xl md:text-4xl font-semibold text-center mb-8 md:mb-12 text-primary">
            Key Features
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
            {features.map((feature, index) => (
              <Card key={index} className="bg-card border-border shadow-lg hover:shadow-primary/50 transition-shadow duration-300 rounded-lg overflow-hidden group">
                <CardHeader className="flex flex-row items-center gap-4 p-6 bg-card/50">
                  <div className="p-3 bg-primary/10 rounded-md group-hover:bg-primary/20 transition-colors">
                    {React.cloneElement(feature.icon, { className: "text-primary group-hover:scale-110 transition-transform" })}
                  </div>
                  <CardTitle className="text-xl font-semibold text-card-foreground">{feature.title}</CardTitle>
                </CardHeader>
                <CardContent className="p-6 text-muted-foreground">
                  <p>{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>

        <section className="text-center">
          <Button 
            size="lg" 
            className="bg-primary hover:bg-primary/90 text-primary-foreground font-bold py-4 px-8 rounded-lg text-lg shadow-md hover:shadow-primary/70 transition-all duration-300 transform hover:scale-105 focus:outline-none focus:ring-4 focus:ring-ring"
            onClick={() => navigate("/DashboardPage")} // Navigate to Dashboard
          >
            Get Started Now
          </Button>
        </section>
      </main>

      <footer className="mt-16 md:mt-24 text-center text-sm text-muted-foreground">
        <p>&copy; {new Date().getFullYear()} CreatorConnect by Digi4u Repair UK. All rights reserved.</p>
        <p>Empowering E-commerce Marketers.</p>
      </footer>
    </div>
  );
}