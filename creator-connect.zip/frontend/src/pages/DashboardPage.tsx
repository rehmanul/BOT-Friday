import React, { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogTrigger } from "@/components/ui/dialog";
import { Send, CheckCircle, Clock, Target, Play, Pause, StopCircle, WifiOff, Wifi, Loader2, AlertTriangle, LogOut, Settings, UploadCloud, Info } from 'lucide-react';

import useSessionStore, { Cookie as ApiCookie } from "../utils/sessionStore";

const botStats = {
  invitesSent: 1250,
  successRate: 75,
  activeTime: "02:35:10",
  dailyLimit: 2000,
  botStatus: "Running",
};

const StatCard = ({ title, value, icon, unit, colorClass }: { title: string, value: string | number, icon: React.ReactNode, unit?: string, colorClass?: string }) => (
  <Card className={`bg-card border-border shadow-lg hover:shadow-primary/40 transition-shadow duration-300 rounded-lg flex flex-col justify-between group`}>
    <CardHeader className="pb-2">
      <CardTitle className="text-sm font-medium text-muted-foreground flex items-center justify-between">
        {title}
        <div className={`p-2 rounded-md bg-primary/10 group-hover:bg-primary/20 ${colorClass || 'text-primary'}`}>
          {icon}
        </div>
      </CardTitle>
    </CardHeader>
    <CardContent>
      <div className={`text-2xl font-bold ${colorClass || 'text-foreground'}`}>
        {value}{unit}
      </div>
    </CardContent>
  </Card>
);

export default function DashboardPage() {
  const {
    tiktokSessionStatus,
    tiktokUser,
    errorMessage,
    isLoading,
  } = useSessionStore();

  // Select actions individually for stability in useEffect and handlers
  const checkInitialSession = useSessionStore((state) => state.actions.checkInitialSession);
  const connectToTikTok = useSessionStore((state) => state.actions.connectToTikTok);
  const disconnectFromTikTok = useSessionStore((state) => state.actions.disconnectFromTikTok);
  // saveCookiesAndConnect will be accessed via getState() in its handler

  const [cookieInput, setCookieInput] = useState("");
  const [isCookieModalOpen, setIsCookieModalOpen] = useState(false);

  useEffect(() => {
    if (checkInitialSession) {
      checkInitialSession();
    } else {
      console.warn("checkInitialSession action not available from store on mount. Store selectors might need adjustment or store is not fully initialized.");
    }
  }, [checkInitialSession]);

  const handleSaveCookies = async () => {
    const saveCookiesAction = useSessionStore.getState().actions.saveCookiesAndConnect;
    if (!saveCookiesAction) {
        console.error("saveCookiesAndConnect action not available!");
        alert("Error: Save function not ready. Please try again shortly.");
        return;
    }
    try {
      const parsedCookies: ApiCookie[] = JSON.parse(cookieInput);
      if (!Array.isArray(parsedCookies)) {
        throw new Error("Cookie data must be a JSON array.");
      }
      for (const cookie of parsedCookies) {
        if (typeof cookie.name !== 'string' || typeof cookie.value !== 'string' || typeof cookie.domain !== 'string') {
          throw new Error('Each cookie object must have name, value, and domain as strings.');
        }
      }
      await saveCookiesAction(parsedCookies);
      setCookieInput("");
      setIsCookieModalOpen(false);
    } catch (error) {
      console.error("Failed to parse or save cookies:", error);
      alert(`Error processing cookies: ${(error as Error).message}. Please ensure it's a valid JSON array of cookie objects.`);
    }
  };

  const getStatusColor = (status: string) => {
    if (status === "Running") return "bg-green-500/20 text-green-400 border-green-500/50 hover:bg-green-500/30";
    if (status === "Paused") return "bg-yellow-500/20 text-yellow-400 border-yellow-500/50 hover:bg-yellow-500/30";
    return "bg-red-500/20 text-red-400 border-red-500/50 hover:bg-red-500/30";
  };

  const renderSessionContent = () => {
    if (isLoading && (tiktokSessionStatus === "Connecting" || tiktokSessionStatus === "CookiesFound")) {
      return (
        <div className="flex flex-col items-center justify-center h-full py-6">
          <Loader2 size={32} className="text-yellow-400 animate-spin mb-3" />
          <p className="text-yellow-400">
            {tiktokSessionStatus === "CookiesFound" ? "Found stored session, verifying..." : "Connecting to TikTok..."}
          </p>
        </div>
      );
    }

    switch (tiktokSessionStatus) {
      case "Connected":
        return (
          <>
            <p className="mb-2 text-green-400 font-semibold flex items-center">
              <Wifi size={18} className="mr-2" /> Status: Connected
            </p>
            {tiktokUser && (
                <p className="mb-4 text-sm text-muted-foreground">Logged in as: <span className="font-medium text-foreground">{tiktokUser.username}</span></p>
            )}
            <Button 
              variant="outline"
              className="w-full text-red-400 border-red-500 hover:bg-red-500/10 hover:text-red-300"
              onClick={disconnectFromTikTok} // Use selected action
              disabled={isLoading}
            >
              <LogOut size={18} className="mr-2" /> Disconnect Session
            </Button>
          </>
        );
      case "Error":
        return (
          <>
            <div className="flex items-center text-red-400 mb-2">
              <AlertTriangle size={20} className="mr-2" /> 
              <p className="font-semibold">Connection Failed</p>
            </div>
            <p className="mb-4 text-sm text-muted-foreground break-all">{errorMessage || "An unknown error occurred."}</p>
            <Button 
              className="w-full bg-primary hover:bg-primary/90 text-primary-foreground mb-3"
              onClick={connectToTikTok} // Use selected action
              disabled={isLoading}
            >
              <Wifi size={18} className="mr-2" /> Retry Connection (Use Stored Session)
            </Button>
            <DialogTrigger asChild>
                <Button variant="outline" className="w-full" onClick={() => setIsCookieModalOpen(true)} disabled={isLoading}>
                    <UploadCloud size={18} className="mr-2" /> Update/Provide Cookies
                </Button>
            </DialogTrigger>
          </>
        );
      case "Warning":
        return (
          <>
            <div className="flex items-center text-yellow-400 mb-2">
              <AlertTriangle size={20} className="mr-2" /> 
              <p className="font-semibold">Session Warning</p>
            </div>
            <p className="mb-4 text-sm text-muted-foreground break-all">{errorMessage || "Cookies were saved, but the session may not be active. Try logging in."}</p>
            <Button 
              className="w-full bg-primary hover:bg-primary/90 text-primary-foreground mb-3"
              onClick={connectToTikTok} // Use selected action
              disabled={isLoading}
            >
              <Wifi size={18} className="mr-2" /> Attempt to Connect (Use Saved Cookies)
            </Button>
             <DialogTrigger asChild>
                <Button variant="outline" className="w-full" onClick={() => setIsCookieModalOpen(true)} disabled={isLoading}>
                    <UploadCloud size={18} className="mr-2" /> Update/Provide New Cookies
                </Button>
            </DialogTrigger>
          </>
        );
      case "Disconnected":
      default:
        return (
          <>
            <p className="mb-4 text-muted-foreground flex items-center">
                <WifiOff size={18} className="mr-2 text-red-400" /> Your TikTok Seller account is not connected.
            </p>
            <Button 
              className="w-full bg-primary hover:bg-primary/90 text-primary-foreground mb-3"
              onClick={connectToTikTok} // Use selected action
              disabled={isLoading}
            >
              <Wifi size={18} className="mr-2" /> Connect (Use Stored Session)
            </Button>
            <DialogTrigger asChild>
                <Button variant="outline" className="w-full" onClick={() => setIsCookieModalOpen(true)} disabled={isLoading}>
                    <UploadCloud size={18} className="mr-2" /> Provide Session Cookies
                </Button>
            </DialogTrigger>
          </>
        );
    }
  };

  return (
    <Dialog open={isCookieModalOpen} onOpenChange={setIsCookieModalOpen}>
      <div className="min-h-screen bg-background text-foreground p-4 md:p-8">
        <header className="mb-8">
          <h1 className="text-3xl md:text-4xl font-bold text-primary">
            Bot Command Center
          </h1>
          <p className="text-muted-foreground">Real-time monitoring and control of your TikTok Affiliate Bot.</p>
        </header>

        <section className="mb-8 p-6 bg-card border border-border rounded-lg shadow-lg">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <h2 className="text-xl font-semibold">Bot Status:</h2>
              <Badge variant="outline" className={`text-lg px-4 py-1 rounded-md ${getStatusColor(botStats.botStatus)}`}>
                {botStats.botStatus}
              </Badge>
            </div>
            <div className="flex items-center gap-2 md:gap-3">
              <Button variant="outline" size="lg" className="text-green-400 border-green-500 hover:bg-green-500/20 hover:text-green-300 focus:ring-green-500">
                <Play size={20} className="mr-2" /> Start Bot
              </Button>
              <Button variant="outline" size="lg" className="text-yellow-400 border-yellow-500 hover:bg-yellow-500/20 hover:text-yellow-300 focus:ring-yellow-500">
                <Pause size={20} className="mr-2" /> Pause Bot
              </Button>
              <Button variant="outline" size="lg" className="text-red-400 border-red-500 hover:bg-red-500/20 hover:text-red-300 focus:ring-red-500">
                <StopCircle size={20} className="mr-2" /> Stop Bot
              </Button>
            </div>
          </div>
        </section>

        <section className="mb-8">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
            <StatCard title="Invites Sent" value={botStats.invitesSent} icon={<Send size={24} />} />
            <StatCard title="Success Rate" value={botStats.successRate} unit="%" icon={<CheckCircle size={24} />} colorClass="text-green-400" />
            <StatCard title="Active Time" value={botStats.activeTime} icon={<Clock size={24} />} />
            <StatCard title="Daily Limit Reached" value={`${(botStats.invitesSent / botStats.dailyLimit * 100).toFixed(0)}%`} icon={<Target size={24} />} />
          </div>
        </section>

        <section className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
          <Card className="bg-card border-border shadow-lg rounded-lg">
            <CardHeader>
              <CardTitle className="text-xl font-semibold flex items-center">
                TikTok Session Management
              </CardTitle>
              <CardDescription className="text-sm text-muted-foreground">
                Current status of your TikTok Seller account connection.
              </CardDescription>
            </CardHeader>
            <CardContent>
              {renderSessionContent()}
            </CardContent>
          </Card>

          <Card className="bg-card border-border shadow-lg rounded-lg">
            <CardHeader>
              <CardTitle className="text-xl font-semibold">Current Campaign Progress</CardTitle>
              <CardDescription className="text-sm text-muted-foreground">No active campaign. Start a new campaign to begin sending invites.</CardDescription>
            </CardHeader>
            <CardContent>
               <div className="w-full bg-muted rounded-full h-2.5 my-4">
                <div className="bg-primary h-2.5 rounded-full" style={{ width: '0%' }}></div>
              </div>
              <Button variant="outline" className="w-full border-primary text-primary hover:bg-primary/10">
                Manage Campaigns
              </Button>
            </CardContent>
          </Card>
        </section>
      </div>

      <DialogContent className="sm:max-w-[525px] bg-card border-border">
        <DialogHeader>
          <DialogTitle className="text-xl flex items-center"><UploadCloud size={20} className="mr-2 text-primary"/>Provide TikTok Session Cookies</DialogTitle>
          <DialogDescription>
            To connect your TikTok Seller account, please provide your current session cookies as a JSON array.
            You can usually obtain these from your browser's developer tools (Application {'>'} Cookies).
            <Button variant="link" size="sm" className="p-0 h-auto text-xs text-primary hover:underline" onClick={() => alert("Instructions: 1. Login to TikTok Seller (seller-uk-accounts.tiktok.com) in your browser. 2. Open Developer Tools (F12 or right-click -> Inspect). 3. Go to Application tab. 4. Under Storage -> Cookies, find the relevant TikTok domain. 5. Copy the cookies (usually you can export them as JSON, or copy relevant ones like 'sessionid', 'csrftoken' etc., ensuring they are in the correct JSON array format). Ensure 'httpOnly' cookies are also included if possible, though direct browser access might be limited; a browser extension for cookie export might be easier.")}>
                <Info size={12} className="mr-1"/> How to get cookies?
            </Button>
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <Textarea 
            placeholder='Paste your TikTok cookie JSON array here. e.g., [{ "name": "sessionid", "value": "...", "domain": ".tiktok.com" }, ...]' 
            value={cookieInput}
            onChange={(e) => setCookieInput(e.target.value)}
            className="min-h-[150px] bg-background border-input focus:ring-primary"
          />
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => setIsCookieModalOpen(false)}>Cancel</Button>
          <Button onClick={handleSaveCookies} disabled={isLoading || !cookieInput.trim()} className="bg-primary hover:bg-primary/90">
            {isLoading ? <Loader2 className="animate-spin mr-2" /> : <CheckCircle className="mr-2"/>} Save & Connect
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
