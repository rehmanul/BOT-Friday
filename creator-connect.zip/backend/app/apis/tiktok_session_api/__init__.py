from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
import databutton as db
from typing import List, Optional, Any
from playwright.sync_api import sync_playwright, TimeoutError as PlaywrightTimeoutError

router = APIRouter(prefix="/api/session", tags=["TikTok Session"])

COOKIES_STORAGE_KEY = "tiktok_session_cookies_playwright_v1"
TIKTOK_VALIDATION_URL = "https://affiliate.tiktok.com/connection/creator?shop_region=GB"
TIKTOK_LOGIN_URL_IDENTIFIER = "login.tiktok.com" # A substring to identify login pages

# --- Pydantic Models ---
class CookieModel(BaseModel):
    name: str
    value: str
    domain: str
    path: Optional[str] = "/"
    expires: Optional[float] = None # Unix timestamp in seconds
    httpOnly: Optional[bool] = False
    secure: Optional[bool] = False
    sameSite: Optional[str] = None # "Strict", "Lax", "None"

class SaveCookiesRequest(BaseModel):
    cookies: List[CookieModel]

class UserDetail(BaseModel):
    username: str
    id: Optional[str] = None
    source: Optional[str] = "mock" # To indicate if it's real or mock

class SessionStatusResponse(BaseModel):
    status: str
    message: Optional[str] = None
    user: Optional[UserDetail] = None

# --- Endpoints ---

@router.post("/save-tiktok-cookies", response_model=SessionStatusResponse)
async def save_tiktok_cookies_endpoint(request_body: SaveCookiesRequest):
    if not request_body.cookies:
        raise HTTPException(status_code=400, detail="No cookies provided in the list.")
    try:
        cookies_to_store = [cookie.model_dump(exclude_none=True) for cookie in request_body.cookies]
        db.storage.json.put(COOKIES_STORAGE_KEY, cookies_to_store)
        print(f"Successfully saved {len(request_body.cookies)} cookies to {COOKIES_STORAGE_KEY}")
        return SessionStatusResponse(status="CookiesSaved", message="Cookies saved successfully. Please attempt login to verify session.")
    except Exception as e:
        print(f"Error saving cookies: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to save cookies: {str(e)}")

@router.get("/check-tiktok-session", response_model=SessionStatusResponse)
async def check_tiktok_session_endpoint():
    try:
        stored_cookies = db.storage.json.get(COOKIES_STORAGE_KEY, default=[])
        if stored_cookies:
            print(f"Found {len(stored_cookies)} stored cookies for check-session-status.")
            return SessionStatusResponse(status="CookiesFoundButNotVerified", message="Cookies are stored. Attempt login to verify session with TikTok.")
        else:
            print("No stored cookies found for check-session-status.")
            return SessionStatusResponse(status="NoCookieFile", message="No session cookies found in storage.")
    except Exception as e:
        print(f"Error in check_tiktok_session_endpoint: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error checking session: {str(e)}")

@router.post("/attempt-tiktok-login", response_model=SessionStatusResponse)
def attempt_tiktok_login_endpoint():
    stored_cookies_data = db.storage.json.get(COOKIES_STORAGE_KEY, default=[])
    if not stored_cookies_data:
        print("No stored cookies found for attempt-login.")
        return SessionStatusResponse(status="NoCookiesToAttemptLogin", message="Cannot attempt login, no cookies stored in system.")

    print(f"Attempting login with {len(stored_cookies_data)} stored cookies.")
    
    playwright_cookies = stored_cookies_data

    with sync_playwright() as p:
        browser = None
        final_url_val = None
        response_status_val = None
        username_text_val = "Verified TikTok User (default)"
        actual_username_found_val = False
        source_val = "error_before_validation"

        try:
            print("Launching headless Chromium browser...")
            browser = p.chromium.launch(headless=True)
            print("Browser launched. Creating new context...")
            context = browser.new_context(
                user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.102 Safari/537.36"
            )
            print("Context created. Adding cookies...")
            context.add_cookies(playwright_cookies)
            print(f"{len(playwright_cookies)} cookies added to context. Creating new page...")
            page = context.new_page()
            print("Page created.")

            print(f"Navigating to {TIKTOK_VALIDATION_URL} with Playwright...")
            nav_response = None
            try:
                nav_response = page.goto(TIKTOK_VALIDATION_URL, timeout=30000, wait_until="domcontentloaded")
            except PlaywrightTimeoutError as nav_timeout:
                print(f"Playwright navigation timed out: {str(nav_timeout)}")
                if browser and browser.is_connected(): browser.close()
                return SessionStatusResponse(status="Error", message=f"TikTok page navigation timed out: {str(nav_timeout)}")

            final_url_val = page.url
            response_status_val = nav_response.status if nav_response else None
            print(f"Playwright navigated. Final URL: {final_url_val}, Status: {response_status_val}")

            if TIKTOK_LOGIN_URL_IDENTIFIER in final_url_val.lower():
                print("Session invalid: Redirected to login page.")
                source_val = "redirected_to_login"
            elif response_status_val and response_status_val >= 400:
                 print(f"Session potentially invalid: Page returned status {response_status_val}")
                 source_val = f"http_error_{response_status_val}"
            elif TIKTOK_VALIDATION_URL not in final_url_val:
                 print(f"Session potentially invalid: Navigated to an unexpected URL: {final_url_val}")
                 source_val = "unexpected_redirect"
            else:
                print("Session appears valid so far. Attempting to scrape username...")
                source_val = "verified_no_username_element_found"
                try:
                    username_element_on_affiliate_page_selector = 'span[data-e2e="seller-center-user-name"]' # Guess
                    print(f"Attempting to find username with selector: {username_element_on_affiliate_page_selector}")
                    page.wait_for_selector("body", timeout=5000)
                    
                    username_element = page.query_selector(username_element_on_affiliate_page_selector)
                    if username_element:
                        text_content = username_element.inner_text()
                        if text_content and text_content.strip():
                           username_text_val = text_content.strip()
                           actual_username_found_val = True
                           source_val = "scraped"
                           print(f"Successfully scraped username: {username_text_val}")
                        else:
                            print("Username element found but was empty.")
                            source_val = "verified_empty_username_element"
                    else:
                        print("Username element not found with the specified selector.")
                        source_val = "verified_no_specific_username_element"

                except PlaywrightTimeoutError as e_scrape_timeout:
                    print(f"Timed out waiting for page elements: {str(e_scrape_timeout)}")
                    source_val = "verified_timeout_waiting_for_page"
                except Exception as e_scrape:
                    print(f"Error scraping username: {str(e_scrape)}")
                    source_val = "verified_error_username_scrape"
        
        except PlaywrightTimeoutError as pte:
            print(f"Playwright setup operation timed out: {str(pte)}")
            if browser and browser.is_connected(): browser.close()
            return SessionStatusResponse(status="Error", message=f"TikTok connection setup timed out: {str(pte)}")
        except Exception as e_main:
            print(f"General Playwright error: {str(e_main)}")
            if browser and browser.is_connected(): browser.close()
            return SessionStatusResponse(status="Error", message=f"Playwright error: {str(e_main)}")
        finally:
            if browser and browser.is_connected():
                print("Ensuring Playwright browser is closed.")
                browser.close()
            print("Playwright block finished.")
        
        if TIKTOK_LOGIN_URL_IDENTIFIER in (final_url_val or "").lower():
            return SessionStatusResponse(status="InvalidSession", message="Session cookies are invalid or expired (redirected to login).")
        if response_status_val and response_status_val >= 400:
            return SessionStatusResponse(status="InvalidSession", message=f"TikTok page check returned HTTP {response_status_val}. Cookies might be invalid.")
        if final_url_val and TIKTOK_VALIDATION_URL in final_url_val and TIKTOK_LOGIN_URL_IDENTIFIER not in final_url_val.lower():
            user_detail = UserDetail(username=username_text_val, source=source_val)
            print(f"Session appears valid. User: {user_detail.username} (Source: {user_detail.source})")
            return SessionStatusResponse(status="Connected", user=user_detail, message="TikTok session validated successfully.")
        
        print(f"Could not confirm valid session. Final URL: {final_url_val}, Source: {source_val}")
        return SessionStatusResponse(status="InvalidSession", message="Could not confirm valid session on TikTok. Cookies might be invalid or page structure changed.")
