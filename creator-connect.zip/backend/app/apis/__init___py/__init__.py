from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field # Field might not be used here directly but good practice
import databutton as db
from typing import List, Optional, Any # Added Any for mock_user flexibility

router = APIRouter(prefix="/api/session", tags=["TikTok Session"])

COOKIES_STORAGE_KEY = "tiktok_session_cookies_playwright_v1"

# --- Pydantic Models ---
class CookieModel(BaseModel):
    name: str
    value: str
    domain: str
    path: Optional[str] = "/" # Default path to /
    # Pydantic will try to convert incoming numbers/strings to float if possible
    # but frontend should send a number (timestamp in seconds)
    expires: Optional[float] = None
    httpOnly: Optional[bool] = False # Default to False
    secure: Optional[bool] = False # Default to False
    # Allow "Strict", "Lax", "None", or null. Empty string from frontend becomes null.
    sameSite: Optional[str] = None

class SaveCookiesRequest(BaseModel):
    cookies: List[CookieModel]

class UserDetail(BaseModel): # More specific user model for response
    username: str
    id: Optional[str] = None # Example, adapt as needed

class SessionStatusResponse(BaseModel):
    status: str # e.g., "NoCookieFile", "CookiesFoundButNotVerified", "Connected", "Error", "CookiesSaved"
    message: Optional[str] = None
    user: Optional[UserDetail] = None

# --- Endpoints ---

@router.post("/save-tiktok-cookies", response_model=SessionStatusResponse)
async def save_tiktok_cookies_endpoint(request_body: SaveCookiesRequest):
    """
    Saves TikTok session cookies provided by the frontend.
    The frontend is expected to have transformed cookie values (like expires, httpOnly, secure)
    into the types defined in CookieModel.
    """
    if not request_body.cookies:
        raise HTTPException(status_code=400, detail="No cookies provided in the list.")
    try:
        # Convert each Pydantic CookieModel to its dict representation for storage.
        # exclude_none=True is good to avoid storing lots of nulls if fields are optional.
        cookies_to_store = [cookie.model_dump(exclude_none=True) for cookie in request_body.cookies]
        db.storage.json.put(COOKIES_STORAGE_KEY, cookies_to_store)
        print(f"Successfully saved {len(request_body.cookies)} cookies to {COOKIES_STORAGE_KEY}")
        return SessionStatusResponse(status="CookiesSaved", message="Cookies saved successfully. You can now attempt to verify the session.")
    except Exception as e:
        print(f"Error saving cookies: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Failed to save cookies: {str(e)}")

@router.get("/check-tiktok-session", response_model=SessionStatusResponse)
async def check_tiktok_session_endpoint():
    """
    Checks the current TikTok session status by looking for stored cookies.
    Does not perform live Playwright validation in this version.
    """
    try:
        stored_cookies = db.storage.json.get(COOKIES_STORAGE_KEY, default=[])
        if stored_cookies:
            print(f"Found {len(stored_cookies)} stored cookies for check-session-status.")
            return SessionStatusResponse(status="CookiesFoundButNotVerified", message="Cookies are stored. Verification with TikTok is the next step.")
        else:
            print("No stored cookies found (or file empty/not found) for check-session-status.")
            return SessionStatusResponse(status="NoCookieFile", message="No session cookies found in storage.")
    except Exception as e:
        print(f"Error in check_tiktok_session_endpoint: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error checking session: {str(e)}")


@router.post("/attempt-tiktok-login", response_model=SessionStatusResponse)
async def attempt_tiktok_login_endpoint():
    """
    Attempts to "log in" by checking for stored cookies.
    Simulates a Playwright login attempt for now.
    """
    try:
        stored_cookies = db.storage.json.get(COOKIES_STORAGE_KEY, default=[])
        if stored_cookies:
            print(f"Found {len(stored_cookies)} stored cookies for attempt-login.")
            mock_user = UserDetail(username="MockTikTokUserFromBackend", id="backend123")
            print("Mocking successful login as Playwright validation is pending.")
            return SessionStatusResponse(status="Connected", user=mock_user, message="Login successful (mocked).")
        else:
            print("No stored cookies found for attempt-login.")
            return SessionStatusResponse(status="NoCookiesToAttemptLogin", message="Cannot attempt login, no cookies stored in system.")
    except Exception as e:
        print(f"Error in attempt_tiktok_login_endpoint: {str(e)}")
        raise HTTPException(status_code=500, detail=f"Error during login attempt: {str(e)}")
